import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthComponent } from './auth/auth.component';
import {POCComponent} from './poc/poc.component';
import { ExceptionDashboardComponent } from './ojp-dashboard/exception-dashboard/exception-dashboard.component'



const routes: Routes = [
  {path: '', component: ExceptionDashboardComponent},
  // {path: 'auth', component: AuthComponent},
  {path: 'dashboard', component: ExceptionDashboardComponent},
  {path: 'poc', component: POCComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
