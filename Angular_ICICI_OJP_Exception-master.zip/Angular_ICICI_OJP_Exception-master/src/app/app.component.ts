import { Component } from '@angular/core';
import { SaveExceptionEmployeeModel } from './model/api.model'
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

}
