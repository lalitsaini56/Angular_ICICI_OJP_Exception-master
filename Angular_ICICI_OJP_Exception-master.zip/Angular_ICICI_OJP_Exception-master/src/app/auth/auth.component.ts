import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OjpExceptionService, ResponseCode } from '../services/ojp-exception.service';
import { PopupMessageService, MessageType } from '../services/popup-message.service';
import { EncryptionService } from '../services/encryption.service';


@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  constructor(private router: Router,
    private ojpExceptionService: OjpExceptionService,
    private popUp: PopupMessageService,
    private Encryption: EncryptionService) { }

  ngOnInit(): void {
  }
  IsShowLoader: boolean = false;
  OnSubmit(employeeId: string, password: string) {
    if (employeeId == '' || password == '') {
      this.popUp.DisplayPopMessage('Login', 'please enter employeeId and Password', MessageType.alert);
      return;
    }
    // console.log(this.Encryption.Enc(employeeId));
    this.IsShowLoader = true;
    this.ojpExceptionService.OJPEmployeeExceptionLogin(employeeId, password).subscribe(res => {
      if (res.StatusCode == ResponseCode.Success) {
        sessionStorage.setItem('CTPushID', res.CTPushID.toString());
        sessionStorage.setItem('Token', res.token);
        this.router.navigate(['/dashboard']);
      }

      else if (res.StatusCode == ResponseCode.NoRecordFound)
        this.popUp.DisplayPopMessage('Alert', 'Invalid EmployeeId or Password', MessageType.alert);

      else if (res.StatusCode == ResponseCode.InvalidEmployeeID)
        this.popUp.DisplayPopMessage('Alert', 'Invalid EmployeeId', MessageType.alert);

      else
        this.popUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);

      this.IsShowLoader = false;
    }, error => {
      this.popUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
      return;
    })
  }
}
