import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { OjpExceptionService } from '../services/ojp-exception.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private _router: Router,
    private exceptionService: OjpExceptionService) { }

  ngOnInit(): void {
  }

  OnLogout() {
    this.exceptionService.logout();
  }

}
