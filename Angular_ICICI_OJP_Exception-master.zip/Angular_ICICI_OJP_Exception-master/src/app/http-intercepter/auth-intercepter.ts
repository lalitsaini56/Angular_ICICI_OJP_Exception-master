import { Injectable } from '@angular/core'
import { HttpInterceptor, HttpRequest, HttpHandler, HttpResponse } from '@angular/common/http';
import {EncryptionService} from '../services/encryption.service';


@Injectable()
export class AuthHeaderInterceptor implements HttpInterceptor {

  constructor(private Encryptor: EncryptionService){

  }

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    const authData = this.Encryptor._encryptDataUsingAES(sessionStorage.getItem('hire!auth_uid') + '::' + sessionStorage.getItem('Hire!Enc.Token') + '::' +  localStorage.getItem('H!reCr@ft.enc_empID'));
    console.log('authData : ' + authData);
    const authToken = request.clone({
      setHeaders: {
        Authorization: authData,
      }
    })
    return next.handle(authToken);
  };
}

