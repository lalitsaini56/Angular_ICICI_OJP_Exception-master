import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthHeaderInterceptor } from './auth-intercepter';

export const authInterceptProviders = [
  {provide: HTTP_INTERCEPTORS, useClass:AuthHeaderInterceptor, multi:true}
];
