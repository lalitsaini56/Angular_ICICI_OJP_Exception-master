import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { OjpExceptionService, ResponseCode } from '../../services/ojp-exception.service';
import { MessageType, PopupMessageService } from '../../services/popup-message.service';
import { SaveExceptionEmployeeModel } from '../../model/api.model';
import { EncryptionService } from '../../services/encryption.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css', '../../global/css/modal.css']
})
export class AddEmployeeComponent implements OnInit {
  @Output() IsDisplayAddEmployee = new EventEmitter<boolean>()
  @Input() IsNewEmployee: number;
  @Input() ChangedStatus: boolean;
  @Input() UpdatedEmpID: string;
  @Output("getexceptionEmployee") getexceptionEmployee: EventEmitter<any> = new EventEmitter();
  constructor(
    private ojpExceptionDashboard: OjpExceptionService,
    private popUp: PopupMessageService,
    private encrytion: EncryptionService,
  ) { }


  IsDisplayEmpDetails: boolean = false;
  IsDisplayRemaks: boolean = false;
  IsDisplayEmpID: boolean = true;
  employee: any;
  EmployeeDetail: SaveExceptionEmployeeModel;
  NewEmpID: string;


  ngOnInit(): void {
    if (this.IsNewEmployee == 1) {
      this.IsDisplayEmpID = true;
      this.IsDisplayRemaks = false;
    }

    else {
      this.IsDisplayEmpID = false;
      this.IsDisplayEmpDetails = false;
      this.IsDisplayRemaks = true;
    }
  }

  CloseAddEmployeeModel() {
    this.getexceptionEmployee.emit();
    this.IsDisplayAddEmployee.emit(false);
  }

  SaveEmployeeDetails(remarks: string) {
    if (remarks == '') {
      this.popUp.DisplayPopMessage('Alert', 'Compulsory to add remarks', MessageType.alert);
      return;
    }
    this.EmployeeDetail = new SaveExceptionEmployeeModel();
    this.EmployeeDetail.remarks = remarks;
    this.EmployeeDetail.CTPushID = sessionStorage.getItem('CTPushID');

    if (this.IsNewEmployee == 1) {
      this.EmployeeDetail.empID = this.NewEmpID;
      this.EmployeeDetail.isNew = true;
      this.EmployeeDetail.status = true;
    }

    else {
      this.EmployeeDetail.empID = this.UpdatedEmpID;
      this.EmployeeDetail.isNew = false;
      this.EmployeeDetail.status = this.ChangedStatus;
    }

    var EmployeeList = [];
    EmployeeList.push(this.EmployeeDetail);
    console.log(JSON.stringify(EmployeeList));
    this.ojpExceptionDashboard.saveOJPExceptionEmployee(JSON.stringify(EmployeeList)).subscribe((res) => {
      if (res.ResponseCode == 100 && this.EmployeeDetail.isNew)
        this.popUp.DisplayPopMessage('Success', 'EmployeeId Added Sucessfully', MessageType.success);

      else if (res.ResponseCode == 100)
        this.popUp.DisplayPopMessage('Success', 'Exception status updated', MessageType.success);

      else if (res.ResponseCode == 101)
        this.popUp.DisplayPopMessage('Success', 'Employee Already exists.', MessageType.alert);

      else
        this.popUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
    }, error => {
      this.IsDisplayAddEmployee.emit(false);
      this.popUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
    })
    this.getexceptionEmployee.emit();
    this.IsDisplayAddEmployee.emit(false);
  }

  GetEmployeeBasicDetails(evt: any) {
    this.NewEmpID = this.encrytion._encryptDataUsingAES(evt.target.value);
    this.ojpExceptionDashboard.getEmployeeBasicDetails( this.NewEmpID).subscribe(res => {
      if (res.ResponseCode == ResponseCode.Success) {
        this.IsDisplayEmpID = false;
        this.IsDisplayRemaks = true;
        this.IsDisplayEmpDetails = true;
        this.employee = res.Data;
        this.NewEmpID = evt.target.value;
      }

      else {
        this.popUp.DisplayPopMessage('Alert', 'Employee ID not Exits in Database.', MessageType.alert);
        this.IsDisplayAddEmployee.emit(false);
      }
    }, error => {
      this.popUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsDisplayAddEmployee.emit(false);
    })


  }
}
