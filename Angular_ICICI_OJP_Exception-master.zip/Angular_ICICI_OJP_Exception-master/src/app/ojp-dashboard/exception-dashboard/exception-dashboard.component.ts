import { Component, OnInit, Output, Inject } from '@angular/core';
import { OjpExceptionService, ResponseCode } from '../../services/ojp-exception.service';
import * as XLSX from 'xlsx';
import { PopupMessageService, MessageType } from '../../services/popup-message.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { EncryptionService } from '../../services/encryption.service';
import { ConfigData, APIResponse, OJPLoginResponse } from '../../model/api.model';


@Component({
  selector: 'app-exception-dashboard',
  templateUrl: './exception-dashboard.component.html',
  styleUrls: ['./exception-dashboard.component.css'],
})
export class ExceptionDashboardComponent implements OnInit {
  IsDisplayAddEmployee: boolean = false;
  IsDisplayRemarks: boolean = false;
  IsDisplayExcelResult: boolean = false;
  IsShowLoader: boolean = false;
  employees: any;
  ExcelResponse: string;
  IsNewEmployee: number = 0;
  ChangedStatus: boolean = true;
  updatedEmpID: string = '';
  RemarkEmpID: string;
  pages = [];
  employeeID: string = '';

  constructor(private ojpExceptionDashboard: OjpExceptionService,
    private PopUp: PopupMessageService,
    private router: ActivatedRoute,
    private Encryption: EncryptionService) {
  }

  ngOnInit(): void {
    this.checkSession();

    if (this.employeeID == undefined || this.employeeID == null)
      this.PopUp.DisplayPopWithoutConfirmation("Error", "Access for this portal not allowed", MessageType.error);

    else {
      this.OJPValidateEmpID();
    }
  }

  checkSession() {
    // const eid = this.Encryption._encryptDataUsingAES('1234');
    // localStorage.setItem('H!reCr@ft.enc_empID', eid);
    // const config = 'U2FsdGVkX19bDVdBsXJB4SEszssrgqkr18RX7wHrZ4YtcM41Exw2Jd6iRz9p3BHti+LUQ+t0I4tCctHZxJqLcp4gygUuuV066R/MIaFlGdM7YXL1eF/dbYMgyEGR+Bj1is4wY4Z4hz5EoN1dO7R2xgAseMNJ7MIcI8dys0xr8VWkr4vtwf7O1YIJs8K/+9uu2kPZZxpkLGxqieGLzvSszWdR8iEFdNRTpwKCK/OCBQ1MjZ5dsRKgdYxI81pH3HPNRuwGttR+xToseBTUeMtyFzQy/TTI6NsgVNftndM5GkXH8YLA6jj/kYKNR28Db4sdBmsJ6x/f/heNMaScWoz67O10slr2M4ulRTmwWh5oNZs1g8nA8oYONv55Xjr9VS0jHq3vKcDROJrZNPALdLm4MnuM1KWfnCHfHhK4JDQsogmgCYAzKKECkIQ03krUyKS4Xp2Z4WGxnXioclyKp/RzcKZOkLUZPvulU65KufEXI6WdrsYYVRueXk6ovVxSXK7vkakEnqhsKZohhHO/egxakwcMoW9Rm6DmZjWWQEOU6zJ2b7gMjnYWpKazJKMU2OAHnD7x+g0YxZNXJXjTpKWglwjuNMVVdQ0t7m2bigTcl7VL+tTNeV35EeStJgRD51V3zJtg9EaTzlR6G8GmYA37Pr3CrfFjOfqRmcSybY9CZfT/yIzX5kQ/0b2bWRBJPPQvjmdLCBKtOvH3geigdWB5PtmO4zfsd73d61F9EAg3d+3ozrkj0P6TR721d+StUdU/uOfyTJjo3CSjbGpEsX4NFzP/Q8QyqDqREOa/gsR2kwZizL4aqsDqr2AMS/tGZcJpMOhvPofZVYaGjrfkMvfUcmOifrA37KFTyx9Wn/yqhZ8y8lo86AMl1VbGsBS/SsXnu/g3ep0ZUoQc8oz1p5j5fI3qDH13fbrD7wE4pRaUx3MYNFhDGrJpd74pJGf4gUKPsSfCj8EBrGpWASmTB5amB+U4GrXw4+AMa7SpHSo2uEniDBxO18TkIB7Mbzyyw5vly35Bx9e7P5YGJfNlQCogEMGiomT6cHdE9YE1356LHVx1cQK0zABfJwbPgnLlaZCXakADPHxYKDAaYFwiW0l7KxCZYALRJRFiE/JJ0DggqPgLsIGVPMR3/xxjW34PwDSXSm8LCjBtaGcUAK/2xoQpwkam7ioWMJ+WhGCzLa5VgBfwRJF4wMRouvUddIV2DJkIhmprhQ0odN8da0FQF2IHGLVbz3nqVjxHt0KPeH2Xpd4VBuzJXHixDBbzSnqD1G8OlvFOXZszQSt6erY4vr+hfZpS7Qmr9V83iu5SD+yLB2RYYhoUMsLxmL/Ot//11igcTLg21zNPizqCAVa3iLqDWSNtsF3fRfVVnUPm02UDtFBc4MhlKIkV2nXF+LAeI5kUc1GtaoYza1xWgaWqX8a7FSb1XHiolOjCsHNAyWRfLIFknoqPApgIicO8ZeAOFCRhT7L004QOm7j217N3slXFSK+C/x5b52U/q2lUgI209msYgdkwrR3Kfm459cgOvf8eNrX7cnAOlU63iX2y427jE5LI5ZptJWp5nIpPb+V5edyM+SI/30wBXs26YXqE5TVmT1XVUsWyJC/kwze+Eh4oeve7ucjJNAP3fncee4G0R223E87gsxAJ6xxIDBn5JjD96S8f16P8fo5HSCJRr4uV9ES5D/lMztHtSVl6jn1GiLs4/1nE3usspCef0c8JSF5Lgh4+IqLaSyikrjuB3xecajMug15xieLPTdmWSmw+A2sXee1v0p1homqTKOl0j8ImWcCTHwojkAxXw1jGQj3XLh3R8xFi0mHA0ZpUByGGjwb44R1qp82+Qi8Y+/GeYDUMWV40r18RIXDxdexIFX+svdnDOQTNFFEuL0R2KJPTbIAqELL7e99j5sepBUHAy6EFLiggR+fc+mEieNx/sTS1G5437lPzMT9HroV1djVU++9UYlgeLB+4niZ/NR5o1sD7dNCvco01CTwCK83cbPJRlMUGQv32OMGmRSWSuskGnFeTIy1G5ooCs2BZRg8/oEhfJle2aolW386ZABuZeRL+7S18t/x5tEul9g1vVZibAqt1cQRO3MtJKLdzIdJiaCUTl9cIIPRv7gtoajGVK3eocEdPuvF93tufSmtrWE12bzql1iQT+NEZck7cd80cNFNAcyPUtd7EApWEiR0BCALxg/qQzIxGkVahog7BXdKAL/h5M0NSNaEOWyMzyEA+amb5aoIZO2QWgkSjXDd3AG3ZMsrpOFFLKhuKTFi3s38Ma+i2myIppTFX1F/oUY7HkSBRphRoKx3Eoy0ENkMdU6QzJP21DvoJZxXF2y2wMDT1AeZGyOJxz2fXYgVqK3Yv8PBRwpaFHtD0VW+tvAqP4mt1u2Dc3C9mY9K564O0nea5s2mhVj3oCLeEdnyZslmyx/NijVLvVz/gZAGwQhJEslyjQjCBCYcnr1KMUzKu5WN4CZHyEbIjYzyi7oNYy80rq2MkNMisOlH4pclSDBB/kSDepwPKsyODboNaeSXttFU+DzGVxXVhhD33rUoSuljzgeyTPxxHMhENYyCGVfWbtJwrAPiOcJos9beh2TJ9PMicFuIiGUB3WwCujWRMnDqbMW6ebWZXCPIDigWNR7AzT+dmzZuhbSVyaJ4MHY6fpA6AaOuoDW3RE6v9d3gRoqpamOdhgDlB6vsIK0Hwcz4j6Z8fkXhXdnh66WN0U0V7Cbp8zOvbRDbUjztqlCUK803bDLOYvzkH/aRZqXMnQ/xD2jbPTvZKgGCjYQf57L5VQG2tH664F1ll4Zqa9n+PS8SYpulII386Tz4QiJA3llnk9CAA4vrCMqZ9zgUeV21IYTREw26UI60QHsIMmw2gmpsCFhQzWT8CyirZD00l9mSZn26Sxyh8hb91a1i26oUGXvccBdIe8hbMNEMYdTutfUwMhYyGxDGJziNk56tzMFeglgDTZ9VPJ+C2H+gzQhkgmbXHXLuAQ6D2OJsPfYmX3QWfI8fRls2om9jwUJN+8e/3666zxti+RJjBxTvSFzNDj6/q+c4I8KOW/zHk9CvfQijBulrZDEJIVOzjQlss/tdS5mMIfh67GdYNOj/x5V94JrWPo+gkHagYqy5Tnq+Jw8UVVOTB6zv9Da2r2KFaNhC/Fgx/eJRHY7qzZk3ClDBXOaZToLG2eqsAnLLvNcHAksMo//np2eB0DvmTuXri4Y5+tRt55LZMKT7X6TWc/1tpGVh36cHJGfI+/JAIP23PMYjCGrIi3k6wHQVtJ0gknxrQOI8KRkTErKiPbf4E0OhRhSkhSnbMG0jlqfXSbzzlK/RN89u9KQr2+lK43HyOkJU1ZhGsV4RC+vSsFzF0mqL6bk+xdqXl0gwfjOB737vvf9ewWuEhmMtmWT7wbIx3uwfUA2aBoskxwfkJZARJdQTwOsXwAFRXMM6XNBXN4ibUENBQAV4HmDV9Bqj+pMxS56//xDWUOg3Ej4+fix2+ORJ5KrJPblLeTwJ3ocvJGUVUGpBmBOlJgqhsgMR9uvcS3zPm1o5+w1/dVJ9f55eSXmpbZCbANJ6QcXT281KzmGypjll+LgyWZevPS1OELFl4o7FRsKmcA95HBLUNL68rcmUdgxjiyeou5xhAJggYA2bFoihv2PeiLkvPy7FEmKJPanwS2WQY1J4aVT5IVicgkw5vl5RsiVvI/+7xAlAKvjCGeU0mULp4KOChry0JrJp9BG4rh27br9/bHaLNNYCQGposqNYIaMpAAsmEEWloUWmGLRG1NnKzQngPLlbE24P5WaPFCa65AapYCmluczu89wgzByYRYSLlr7Xe9WdFadvaiCjzrSwEu119d+EfxEEVB7nGjDdeMp2TfBpwqW4fNPUx9dtOaRDWexFkEIn6NegSIqLeUQlUCHCQy7bV/t4BX1hDqGPleFcpE1hvuyGD8dt9Bh4qlfJLdqTcPreiBDHjssmixF12u+qWRAzqnUT8ll+Ym4h/trUeFI9G9fjRKhgGKCZa1vTXS8beY2XSFZMZMBA44ujKMgYl5/YH+ZeOL78mVw44WXUR/r+3jJtIFUS6d1QjpsrjYc/T+VnDR2G3U20DSxEK8p/jZcmwJkuzlvQkFGLgwH69ClvbC88ChJwQVdSXvOjazKDYIHzDZTuDn/JUVIyjbYJkxn8lwBhZFr3doSCajjOMMxQZr9sdTlqfxgrxcmyK2fzqOP4Ios8eZn6ixbZnU4KGjI6BnYOLa9WrO6x907UtlRvsB+DGSpmJIWqM1+/5AEq+whocu/bAND5uLPrm30PRgGdXq7pdmf/Nx1T1pAfpUEFqr8/1Wkb5XNlncU+J+9r8jNqZSWjBDUuKI6fpSR+GJyoxJNU1EtuS8CI9/zrnnez/vAiAjxO8vHM2SACxYwRgY21u3NkFLu/BWTaMs6sIir6INzOs5YbL8dGKHkRlPb5siYRF4W3+NgvC9ZzzDT2z9DHB7NodJazd8NG4sKC+sLvpo8dzV36EU8+/aFWZOO8UBegSiDs1PbeVHmd2jyZgqLM8HW+JoPhKTQBdETwhP6BTZofDafb+l0C418c7ejO5vE0hu/Loc4I5O0tIwI3j6XsRHdWINMc44AVFfJQfHORckRfvubU1Iz7f6U3Fm4P6+DLLp9HKoOmovfxJ4lRjRJhmup7whQqKeO/eAITIpNRBxkPd8iN12SyXZpJgr4LUDcmrWw32EzVX8jS06+9nQp92lw1EnOzRpJHYRLDFGYkzWNK6RyL7pFB8k8uaSjHSG87x043kedZ6LPWLZyCQ5vwjaN0OkN1SW5ify9EuhgnmA2KqCbowCFlAJaiUlkMEr329YHUBegTvmU5ew4Nw1sFY0FZhuTXPc/xWEBCbxdVyvQvziOnsTNJ9VGvfN8d7KGjydtmhlcH0XbPqNzN8xkPp9QXZill2uiPDNVcLBd0BCNno5rveiNAUmKkGaj4NBUUoxqQLvfH5cKbxXz9rMIp9XwxcFpihFHQvS16FbTxV+j06okFJjju0+r0bgu9CMfwGfsjjrQVbXBmstKZFrXLaeWoDy9aZJ1ahS3qaXUheKrNPWuHa9T/q7lbA4eXt/RLc2k17SRBwV6BjicJKDQvcGTBCEe2YNzpfHaPZUdNyJKQ39g25tODrEI/EjjUtKZFNYpNQ2MKNgsMalA1MGhCg3UtPT2J/MfYz4BQtxrJ5FkuliUL4Q/Cy8PDNHfZ1G2zorj96HenGikl1si9BNnYEwA7A0+ar5E3R4VoWd8pSLQYNky6HU2gCE0Rhvt2tQDkRI8E+7jUFWIu5Jv7Q/1gO+giYAjjyvMKzuZKPiOj4ibcPg9YHdp5atHqCjIWDuC4V84xsPp0Sd51edqSmWkmUAIH5ya9cDntUB4MbrqmPHQGlxO9umiijd4uGR8fj4unwNDenH73r9QUHfrUZKSpzTeQnJkoIokD8tlWDrUUS9pEOUmYVpVw4uaneRaXatAo8tUz6Es3q1KIBoxXvvSF0i3gbIMpzG5hXcoJy4DuWMYC9oUpdz5hKnihBeVMJG4PnM+g/w1vbk5shrAjNpxwFJvQdTDWCj7fl84WQLlN0hUBV2UCZTxta7REPyJaTmdbx5hzmObIVcGY2dtG4/eMEpNVg980ITlk55qZHCCbyYlz3MiPrOxhMKY7wIw0Ft54n1Vwp/l1ehjK4YCHYaCDFjw+SokVSJp7Pvxk01qDZ1khFjvUIo2/ISXXxPbtrPulFZPBooF8WtCC6NLxkFPxfOMC9u25mtYOl9DcL/NDLU4SNiUmdorfWAw7syPoEfWSZ8Xw4ZFeooydYtZh5Y+oB18VGyyT7Q71xxOHEbGv6YDn2aTWg87x/Az2LsqAEtpJb8HKzRH8RR95Cudr16v3gPTQDYqkF3uUGaMFFiwsmECcx4La6SJUglFfvgHHBqiCFqQP3PcpaMizESLJby5hJKwCP4xZdFC0uLHOfqb6felksdJFdxn4mWwssKY36orwKXBSCHm7U5bY/NH1ufm58wEkh6B4Tg030wA0RLrjvaGaX74wl60Ar3TYL94QYpNuAPIG+LMcQumJknToYvgANkBWVdeCVr7KxapfxbUAX1uMa9ko1nmGdJzlR1rnFRAiDgt/9F2Zao1MNWKxvXns72zXKAANa0GvWHM9Wgybcqg6Unlc8kOibU6jACi/ejoleFeTBcv0/YkDaQHzp7+DF95xjnDMX0dZXfcdA7bFWOk3Hu9wrhmEX6b7ykd+HoaYZw0adXvsuC1p03JvE9zDfNVTR7QEL8ls1k8kyWAuH6zHHWelkN7Ya40u71Gn7rTOSJgMSqfFYPWge9J9INQXzf9a3lGQCbhRE3nFvyz6vH5BbzSI+tenu6gPqys/sMxWQTyPbia5DEpjhpUNlGSZXD0FJuY8J2LwZLAm1rb1U13UyIF3JCUNwOu4e64yFzZcGIsJNJafmB1aJL505NrGLycKr6JboDuo04usAkG/6mYMrvwVoLmnjTUmcTxUm5WO1dpgGbzXFbBd5/UBqqVaJJjephvyxQBihMqdAlJcm7q8WxXt1K/K4e5uhnx/UdnXzR7zomayBZlLbpu/d8ufc++xv5GzhLk6+EYoUFzDJ3lSnZ6DFTHyTEveaOqMWrGc21OCil/NsnUvFVcEUBWNpiRz5ul919XbzbSUJepKTRdFdNS/TuIvtnEH2QnxHrk7O+q1kQxfF5P3Y5HCIElnKSudfZaspXqNW448AuwiRTxVHDOas1CN7Xhoo0NMEMjiPfqt0HBvjNW5Rq4Eta9MAwnOa18K0jmYjs6iB5Jw3yIqlnfzRXfdXPSqr8YfIQpIbzJCgQyARbs7tfKfKB0dVce8+z3Uy1jqRXzgGVO13zuklZ9aVppcssNrr4qoA4MnmGzm0ZbFW2meGHTGM+ARTRPg9eYcg81S2gYdJT4D7Is8/dWJDp05W2KaSmC7Yk8QLaDHLGeo4fhLmKkwFbyoGepoj5raF10mAEtdsyERvOuBFijmLI3HTVAZl9DBaxNSQK/PR+qK/uPaVeOPb+zQFPb+UPdqc4lbtkU8iZ96oDPAytQpaA4Z1AouacYwDMmTez1xHVOfaCjG2m/+lMeCXYBy2t/suAK6LjtTQZ9xlnvCk92arDH+VWJWhgkuxogKZpCuWvUn6l4m9PAa+XhmKYZsYtdzxy9e7la+6dFoaLF4JloMHjf1dN3Z2rUaBe/e51P7uPS0+q7Ob4nT7XZHGeKyLMsvaUl5ogIK7lEx6xLE7JFUOG1tZbtkWcrRtTpeZjXLrGi7nb60JJQvmcQwqC8unt2oiODCvM4qUQoLTjGw5VnOKbOBjlkQe1Z+/kgQT5bBeZHTm5+V9DnrCvC4HL1dRgQWcevA/f5olx3rR4OC9EGu/ZSSrSiQmE4W64RmqPcIuMLsZ0rpvNI4OObs9083SbZHYfYtrDz7OLBu5qIwWJ8HRYcysxHWjHIOQqSEZbvd/RrOz/+DO23LcfSMS0GDuxuPE59ZCSVP6BaFI1QrW+EADJ9D5DUsI9wlixTvbI+d5e/Vog0bagq9XPEoeQyAciVeQfu5G7/y46Rnoc1d2DpU/oWIyhrDraUnTMei08bRlSMUh1AsiqEln2I2AMpfqJ/CY3n0D9NxeFWmc2q+4byJ460NSEwf4ePWtgiD5XR4iviszKpEfuHla2nQqsw1oMfVMcpVnQz8isJGIHBJuRyoGRzZucvY/LJCQEgQf7ooGUuIgENNBOijzB1qXDrD25RdZOFhq/He0/974EraaIdYZgLoOB1+X22muTl/3KX1yAzswCRdbH0D0bFh9NtVmC6nP+kFwvuEcF9ZNuuJVgGi2AIUm/y3U+FkNWHc1RawV1z5n1jFuSaJAMWTNNHwPW8y6UGo/7EqVbDGjFc74pOZP6igGut81iVdC6qsjeTL3qMEyyqubI8ubms/8OAQJZJovTWxi6C45kXzyqHxLHlQD2pjA7R85WoHzKW0jisAJDyMdCnGEm23dG/c4Vt7pWbfB0veC7n3hh6cvwXFfihQZ1qY+vVFuMcP2jcDl8BgsOJKP9EAIKdNn0EitcTG4FLn9n1DgKOrA5SCjKYqea5aydrRDQ8UjQHm/goVNhBns5BkiCV0gLjaAy1DUScEsDIsr13808/jkQ7E2LnOoeRE4Czs8usWXChiwz5H/JLXTxx3K4Vucm6vf/Llt0IOb7U3S1QcfJC5xmxou3i9AortWEaVCzb4LtZ0qP4227bRvyv2NSde5u8lTNJVas1eWoI+H1ZryiCbE1fRVZpETwmz+0SToVmIn26+k3N4YdUAb9/sXU2lwoR/XADNhFmbhni9swhvzraHqPJDvhOIY0zCIbO3rbuiy7vKZoYibZ/TrVtUt8LLIAxhxpIhM4FeER2rqufyYgekQv3CbW8H24bvrMDnzpf8JP0hgLkhTQgXS37ov4Ni+peT6YvkNYXOhd45nQC5OOrrQQcLcto0vsvDJizKXYnfNqO8ckG4lUHD6vPC3AOZfJNvwE0xu8mfHnTUeVWNeHMM/lTElAcGoI0dbihLNEypQc629Iq4OWXclxZ7Zkhp6qi25ZXhjQXchliURp5cXPD1/lJAIzmPo7zj+shJWbn9mfcf2cX6pm74FmUKPzOoqk3kvv0Qnk+x0nD7n5crNtJQIDP5ssgVdq4WIdNYdBPxxCpEE+NxzeUUL2wSebdWPb0luubMoLMQZXX/faFgj9k+0WFsZj9vvQfoCY1KwVgCl86DwsyhjGejNOVZ/d4aMVbVHVRNh3qyktgwJ2bLef8bGCTozBCxNKMxShosyxHbkpQj3pcCXm7eilX+IL6XpvtCRJ6JFfBD83qKld2dBIQuqGqYPIReft4nxqYKRF6QDfNywspH7c0V1HLo4qSaYb+Li4GtCq2aLcNKYP0yi1yCDwaTShbpsRQESbYwj85+Mej/HhhD1JlYyci5J86Oebmfa8aVStSS8oqT6NL5mN2PDAdfd+toDAkUxzJ+Qhh63NDoH2SKoYWP0TZ5FI59wQYmohU9IprBZvNTeGVTz8Om/rSlHQSB76+iIJ4PZd1IXoyftLTYvZAgh+3PvBtr//p6pfujEy1QEZVCpqkSNUurdYruHtn+CtvQ3d498ABj9rAuRgJpLZTxidSc4ttAr9Ji64GxxShtkcDhJs5EE7YD5rrhKWaaMYC5Tt6KRJxBZ0I25t3IXNmecJFUO3c2Tp57QVkNvt8Z/YzcPYznkaChwiSYkS59L1I9YfKGBTuzKXK+hjT0WeeAVofeYIHp++qs8J2zCyG2a8UHuaWkAtblpndK/l1rdT/DdZMjH/ms+cqku36YVZYozzD+eEiX1p9LCz3u34tl2x6ftwxctUuIbZuEyIEdhVWJK/DrxlFwXuuiUrBO+jjAeE12sqfGnA6YW5EFZ7gK9hzNA/IqbSnDLJl1nWaR2d1x8/qeCNqXpIVLgtCBAZVE+SeTCr8DylkfBqzKSyrUTkQ0G8WSMP0tbmqTEuFrswQ/9YiRQ5LMx0k5ajCKOT/r82ilyeqZwSbucmEfjaDka+1xBmLIlDlq0mMpRi1a9NMLVPtbbrrzBmWT664CVyK9VSKqXY9a3XFkIR/0kvWaYPFJXMFJJTtwErNX9lBZE24mTreChY3W83Ne8Ntd531JD9KQa/vsMvjAioVWsOZyxb9SwQtds3wraplUhWKMxZrVWG06kIuIJZDrIwXFk2T5uguYpBfceCnNqgpdxN+1CvM9g94DCytmEJnegPYZQvSftD9LnXutRVHJmTSx3/5nf1X7deeDvr7Fzf5kxxzdOC+q/KIefmWhvA0A/qmkR+qV7EEzhrwiqtvQ4qx8z5aw18SROA6cm/Mo4KhlB4CjolkQnPxJBlTLxOKkDBqrSZ6/FyJT7OahMIR4uCLXlLGNmf5X9vZxaRY+e5IR46/LtttETogQ1LMstBZyQ2Itpk2Qf5m23CUl7FnEZoCDC0NLlJzOGZ59KWFo0vUSyqWdd/QMYNfgEeZM+KYuAVIa43L4+Yp1I0j5+NrrybP1Oo/r2I/Z/8fhVQYrSRfZaqlNyc8NiSA8u37H+nrmiDbwLK5J1pBuivLc/3PmAijefW/ytRdiUSwz16mbzCRwAfq5GYI89HrXJlb+oVxDh5t1M1QuRicmyTI7pjJt2aZ0LRmgZIEQXKzvuBMjTVjaX7bab0qXyToyMVGvAiCqli8coJpympuCR3v4hp35XLGg9rchBtdjOXClH8nVMh20Vf5PUQXgXgWxdhZmMCFArRz8tvlILCsmjsri8BMLrj4kmrhAnbbrsWhkww9qescqpWI2OLJJ53SVXnyCFnnxmID9Sj4EM6nb9ui7rzEsywCUN81Z0rJectOYVpgo7t3FymJcFM16+pwtcQoV1yh5puOYtpKGJ6WXk7lMr8DZxZ68Py+0aHwEzzbcfZSTftAelTqXv+vfwLqGP3Vop3eiBTnElQ0K64UhYBJ4T+FH/7S/vklFSF/j5wtmB/PNYr360+tWs5WZ1z1+HQnCdndsXYhIQKTjugoXMEqeCBDPdQIXgmKYISK7fEpoDX8TSB1o7HTzAOGbCpkclAh2XtM6mLHVyJ4CktwX/8ORUHxWDdb2e/2xlXtvdT8V0JPKCnOMwFat/q+ih/my4djpEijSeFxWAazD5F4xRbQwLDF3/wOpmnLCbVlDOIBEtl/O39sSdQwZEt7NP1AtoiR4UlnfF8c6kcpWQLfCkl/kMGNB9/Prv62JdKxHVCxrxWPdDI3S/bgnwk1A7Ix/ZfFg5VuT+8j2Ag8tWDs+iNq4DFEr4rmMszaLXCA8bpUPCGXkKPUgjacZB4byTNAXbQvIWYmkW7421PaIZQqQxUlbK0uQtPsY2qMG4s7j2hD2+ktlc/Ip/Ig4dTTXr+SRmkoxSNcx2b7swRzZX3PMmdWZ4MEC+DQU8Y6QkAH3MCmiz8BbYI2xcc7CGBchTRyWTjXAPWjz2PWLgmvITS2Pq5sMOLIBaZyo+NHe2FvvdW57xeyZirUFDZjLen/B+MdrElyYqC6t3yNLf7tWfiK6+fFQnyUj0anXRtfdAjX2qjWty0qbvyAgACCzVPvbxuJrhvpUooZ6TlwXc9c0LRPXRku55W2zJN5qipCT5iBLlwEyGEUP8rMJb8k4DFh8ByuHRf9f+lOfbpM3pGMr1nVfoXXHbEsIAJH+eCtAL2Azd2MPvEZdO1ESi8Qs/6qhAcv0/+YQKaHcQV4LuF/enuXsBlknpLV0TY/mnrjyUrqx9KFRFIvBw2FxDJuI0NNR4RcC2hcojm8hNdnqrZgC1WopeYgYjHy0v3QisYiGwHs+GNc5Vu+QqsX2Nwg4HbYQA5CLD/GFnNOO/PgY8wkQZUq+F61uSwI3lXRisu4VEJn04sAcjkYHPaE8jkHu+pvZWBumq4tWhK59Ls+J8XEpB81TL6agolvHBgeYpnv9x11OAi4jevqYCLzimfZm93jXtvsN4tAss+LHifdlsXrCAqEBqOvfylJnDpmxH95T8dsBzaebYZ7ftswr3Ym5s/0tjr4Psz9Fh6Ke3l+CpkMWSakTK0r7N5Y7DBNPrrUHjrWd2vSEgLh7BoXNPG2AwgMvjrAttDSzGQuWHkAfRQ2ZCDF1WDVDDEMuSzzEoT4kpmjpKaXhO29J4Gqpsfn9CqDX6iBwXWWWV3sdTgO/werHjhtVvxOot6wRd1U20Hsq+OXW6ue8ROsSA0WoK/vgUbfOvg6l8MRo6O8DPH8IajwmqOuci/fS230PU57wi0kC1v/craR1ZaS6cb8HDjNo4M28gnkH2lRdXNfLBSfn65nQfyJ+5GYLRlVgLmmlGopyadqSUtxzCoL2ob6SVM2fZmThu+q5iPjN1CeJqb2BWB+Cs+yzKWs0sVQy72q3ncCVrheD2UalB1nD20uQUt9b8siD+Fuj/ykM4JeKw89N7HDOn9Qr//DSav/x3YR33h/Tx+G5h5YHXL5q0M5H9eV5csDLxwVKKAq4mci0wYpCb12jQRB7rioj+VU+OxLXqX3Cy1tbQd/S21cCc9ylBQYsiTEAKVLJiTOXAhnWjHoZ5X7rdHN8/wl07nYonWGss3a7pyHn+hxY+L3ZRJ87bash+9hSsbpDjLh5UtHHZ/HKNZHHax0GbllnQTPcegn4Apej1a4L7/NrUD55c7KFsmDeJaR2+flKfkcneltGvu9FZcMFofxd7+HvZ38996AK6DOZeyXwHoCjtLQQFve5xUAx8YGFvxw8vZNucFIOa9grd9AYbHV5fiYjMrSlrJC+s445rEXwgvXxhQ7YvyU7G4Cotn6KRznqlOgfNmraSRgfv0ols6LaL5TGC4nAInts1xtPIaTe2J+NSbmX9w1rYaNhl54wjjRSkc6U2+dk85VF3nqOM4G+NdMH3guTwf+tx+CuUxXCNV7Vbz1EtRtYnY5JnWnEaQOvp6oqOc/HCr3T9TftFZz7cQ+rBIm/Y81LNyR8PwcJSF0ohewZBinvPeDGMYrrK+gCBZht897JXzhBKC73QFRr8NLcm6lmFVCeGAiLZio3Og9dwEQ1n6nJ8R2/EGJ+k3Yycg7kSr4NZW2ki1JetQLqVIk3O0xwwcYG3qL/ZIroXc60sl1ChzteIFUjFhe7Til5n/IJun29GSucm6hgB/SVD6bir3qHyn+PkDHR5MFWHWyOomRXhV+Qtv3dqXrXdlhr/z1Zp+t/cb9PJSyknuUGlouR9kETWuPvAl8MYJm16DKKA4ACiKf59Qyf1BANigN2wBIkoY3OhrqGrtOjWftoPN/tgA2k4xMf9Hxwym97xxCdd8EKMac8O8jYcrt2j0jOkmI/4WdikNmWpv6ljOu/+kEqTSvOnbnHUa+KjbqSoqZlHy6v7fbsFoErVycBzP3l1/ugM5AxMx/TkhtdSlMRVsMUdllcH1g6UjqDb3AMMl0dx52SFAoBBLpAorrGS/v51vQUf9oYomTZAB95vcFgbgpg6rCz3rvxNkfYA/OsqLKmEWAfF4zBJQiGQktumW8j2pxjxlhQ/+FW2M9KNc9MEKjg9PoObT3aQpLQv7DHbO4xKfmDqqhj7a1IEs3EbAI1K3aqmGrWlvEGOh0dqkMtCfl3Rym3TLCf4XRt6GXj5MKoYOxoDmRguEMFXItvfNBqnmC4JDJ7o0IbL+OW8lh5FLC1WjVgPbzR7L3A4hjoff4aG97ej9CvRs5J49HaMA7JkVkQ+ttza02PSQHIFYHEtMnXLHk9ZgS83rL30+S4unSvL01HCSRXZp9qmzcxGNza0kkTDgZqq8TPslQumud0+SqHEvZI9BK8T8CmBPREO7dfGKn5aPD9U8SuaOSUaP5PU9sG5WX49912i3r/IOAzzMQAAeOvY4x9Y3Q/tz9V/gPjYJ2TxgQdOofHxaC7y4Lnnl+z3g3d+USZG+StSSd23h/vGBoS5UGMpUvSfTxX38RWFgk9i0R1kTS/y+yQwMh5nZXl2JXNhmQYVRFh7iCKbqvTGRJ6LvfuOd6AIAxBUrVIDjWDui0ea0YrJI0Vfd7+sJ8aK268eMwUsQ17+esXT635xwn7KmVHMT5xnc7e+wVqCP1vw7pLuhwtF9cKXZU8H3GR1qkaF70JixaM5PMQVzGSPmUeq5+akferupH3/cFPr0UD8HWMSeLguAnnWhzD0erAc7L/FWJ+mIoG+KYtBn5Mzo5nvoqp9eF/k3Lpwj06sOGDDwv1inuLMB37Uw2QvfMQ5jepMk9nUOq7NUGlnodc+7Sq2dYQO6hP1sWfYLMXBTUdJpgQzOhAeI8RuNd/Hl7Y57sjoJ6LKB7DFvfXG3Zs4/yOVPhUpWbGUcoDpFpphsmSBZjkiBkkHOX/We2jnO9bEsUiebaZsDZY8hi3JfWla2/2KVZe48JDGb5fo6UR5kvdPcp3pfQ1pn6Oy5d5WPOeISIswNIcOyix5TTQb1+LK9Drums+bVnjI37WcrY8W7JTnIY7STAk7t9dQB18BxxqhmTgee4KtKJLAWLAocKZbJf9hQuprTLBBDff0qmqHuaguiMIi7GGO9B7S3/vfLHoMHFtqo2xUlK1m5bV8r3pcsl+0mRyLMd2VRrdPZypOrVWl//gCLRFymwOx+f1pFE+B1qFdxfhdhGg5V8vhoLCeWfdSGMJ0mUQn8TM8zs6eC65CH3lhB4W/366z+d2auHKbDCSweQtVvisl44pDjYYWf5kiEpXFJ9+gmKs+THK9XQNR+HOao62BKjjRmSjOOcesCvEBykB9FBc2hhWgvjbKAocj1spWb894iIh8lpYrYyAehODND8GdZsVFR/tOsIw4jKHOkI2VZHwbimGCbTWvTKHJ7FZj3cTnGIlWbLzTjwF1mpaw8n9Ynwo3Q6g6LrUZVf5K1IVDS6TY8k9r0n59d14g2JtKXbbucua95LQ3uDVMCqVvfouvvS9Uk14tfAXZz3WDSgaOwipzOAcDfhowXxQkEwDhFKAycfkPbaUOA1JCQecAiq6pGw2s6cfSKTAMqSxWDxup5mXgUrIwjx0rAId/M6cJWI6JpV/7lKmYo9sIFZ3KhVUGzUG5tm4L2yJ32AKn2vg8WPSf0BR02pQPW858hbV9U3bJscsAzb1BocnT/+fzde7Sa3cTFlndRh7FHJg+nm2chjkVRa0rIDeJIkvGErhbLCgOxzkblVl+qBjqHxnvdzh5EC3UmwOp81OAv622jJkBtD+Rb+EgeS5fngGWqP6d6IBAKAW69gyQ96w3bm2kUNOo/HukLINivx8g1mCU0pU4aKVXV39PlN8TyQaT0kUeZNDnnrouH4wDpJZ4dLxAzAOA8jtdJc6Uog13vfvRiPLY+Uqc0wmf65YFSY043KSQXXlARSJIG5uwG/X5CZonvap8CYgsHim1/Tkr+q28S1hPoiMHqpF1hdkNmKpH6nmcCP/9wZcrSwYqTZE+N3nM6Ai6gtaLb7wnpL+AOfu9c9zOllyqEUThr84wrBKLyIIfBuRpAMN9vFVre8poRCMb/HoN4fR7S7V/zl3NEzEEd7OZch0V4xmUaL6rjCs1829FvGaXaCvLbazbREHFg6kW6JQsDovLC90J1gxqjef0YIPnrGXJd2TxSsGjAk08ePbGNu/eKpwp3biUTSRf04S7XQWvyfxAsjmgBxlNqs8lKIPuojBOxE1qIOi07JY3uao4he84bwCs2VHzcEGD6jyEp8cnU4JP2zrvLfUtnEduQvU3FkrdVjQZ78RUsusVxjpeVU9Kzzm45Skp3XROXvC5/wrTrit6GKJehWePB/B8x31r5D5lQ4KAYDatgRkaYhCYNXWC7JS5ftH7p8f62XtcG3JhmFr8L/LqCMcHzm8fOwNNyB4vEZEFeLcLVpwZOKYb0hYK+0kVLlvdqKO/zwi8hQrwnbVsFw0K7pRmE/1ouNuMpTaxCOSgBJLhtv2CFwwKwrGWRPzlFT+X4sh8QkHzBZK+RSyJSaNSDxNbl2wfYD90IhfOhui2krunqf9UMGkUvkrYC6DBt0hjNIeGtlbUThAMI0vJzSTGP0HHL4s+0s2t0QQ0SBVkCMu7rhzRgpmzTPGDfyJAUoPAjFcHIyA9ScCGILzll5LAz57WMT+4h4K78C+XE62fdLkweei+kuEqPiqAhGep7ybXbS29I70WTiC7MfHjC+u2++aLVKo/0vdCPnJjca3zSUaVDdprrIOCaCtH9B/HF2bkTbGAlruE3dZdSucwA0aCzd2sf+LZA0OMMse9i0DUpXqh9YtVQg5mXNF8TrUUV+KOMvOvZQyrpwSz3oajZUiOgkjm8el3EFqC8Wci+xbQHopQnrev9lUxVMRTWmKKJzMUjaBwdvQeeEYnbkVw1R7Xu6hpYYSm64/O6feL2Si1XA=='
    // sessionStorage.setItem('H!reCr@ft.sysConfiguration',config)
    const encSysConfiguration = sessionStorage.getItem('H!reCr@ft.sysConfiguration');
    if (encSysConfiguration != null) {
      let sysConfiguration = this.Encryption._decryptConfiDataUsingAES(encSysConfiguration);
      console.log(sysConfiguration);
      let configData= <ConfigData><unknown>sysConfiguration;
      console.log(configData.UserConfig.UserInfo.RID);
      let userID = configData.UserConfig.UserInfo.RID;
      sessionStorage.setItem('hire!auth_uid', this.Encryption._encryptDataUsingAES(userID));
    }
    else {
      console.log('Piyush');
      this.ojpExceptionDashboard.logout();
    }

    this.employeeID = localStorage.getItem('H!reCr@ft.enc_empID');
    sessionStorage.setItem('Hire!Enc.Token', this.Encryption._encryptDataUsingAES('p'));
  }

  OJPValidateEmpID() {
    this.ojpExceptionDashboard.OJPValidateEmpID(this.employeeID).subscribe(response => {
      this.IsShowLoader = true;
      if (response.StatusCode == ResponseCode.Success) {
        console.log('I am Here');
        // this.employeeID = response.EmpID;
        sessionStorage.setItem('CTPushID', response.CTPushID.toString());
        sessionStorage.setItem('Hire!Enc.Token', response.token);
        this.getexceptionEmployee('', 1);
      }

      else if (response.StatusCode == ResponseCode.SeesionExpired)
        this.ojpExceptionDashboard.logout();

      else {
        this.PopUp.DisplayPopWithoutConfirmation("Error", "Access for this portal not allowed", MessageType.error);
      }
      this.IsShowLoader = false;

    }, error => {
      console.log(error);
      this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
    })
  }

  getexceptionEmployee(EmpID: string, page: number) {
    console.log('getexceptionEmployee');
    this.IsShowLoader = true;
    this.ojpExceptionDashboard.getOjpExceptionEmployees(EmpID, page).subscribe((res) => {
      console.log(res);
      if (res.ResponseCode == ResponseCode.Success) {
        this.employees = res.Data;
        this.LoadPageNavigator(res.NoOfRecords);
      }

      else if (res.ResponseCode == ResponseCode.SeesionExpired)
        this.ojpExceptionDashboard.logout();
      this.IsShowLoader = false;
    }, error => {
      console.log(error);
      this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
    })
  }

  LoadPageNavigator(totalRecords: number) {
    let page_size = 5;
    let MaxPages = 10;
    let TotalPages = totalRecords / page_size;
    if (totalRecords % page_size != 0)
      TotalPages++;

    this.pages = [];
    for (let i = 1; i <= TotalPages && i <= MaxPages; i++)
      this.pages.push(i);
  }

  AddEmployee() {
    this.IsDisplayAddEmployee = true;
    this.IsNewEmployee = 1;
  }

  OnChangeStatus(empid: string, evt: any) {
    this.IsDisplayAddEmployee = true;
    this.IsNewEmployee = 0;
    this.ChangedStatus = evt.target.checked;
    this.updatedEmpID = empid;
  }

  DisplayRemarks(employee: any) {
    this.IsDisplayRemarks = true;
    this.RemarkEmpID = this.Encryption._encryptDataUsingAES(employee.EmpID);
  }

  CloseRemarksModel(IsDisplayRemarks: boolean) {
    this.IsDisplayRemarks = IsDisplayRemarks;
  }

  CloseAddEmployeeModel(IsDisplayAddEmployee: boolean) {
    this.IsDisplayAddEmployee = IsDisplayAddEmployee;
  }

  SearchEmployee(Empid: string) {
    this.IsShowLoader = true;
    this.ojpExceptionDashboard.getOjpExceptionEmployees(this.Encryption._encryptDataUsingAES(Empid), 0).subscribe((res) => {
      if (res.ResponseCode == ResponseCode.Success)
        this.employees = res.Data;

      else if (res.ResponseCode == ResponseCode.NoRecordFound)
        this.PopUp.DisplayPopMessage('Alert', 'Employee Id Not Exist', MessageType.alert);

      else
        this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
    },
      error => {
        this.IsShowLoader = false;
        this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      })
  }

  CloseExcelModel(IsDisplayExcelResult: boolean) {
    this.IsDisplayExcelResult = false;
  }

  UploadFile(evt: any) {
    this.IsShowLoader = true;
    const reader = new FileReader();
    const file = evt.target.files[0];
    var allowedExtensions =
      /(\.xlsx|\.xls)$/i;

    if (!allowedExtensions.exec(file.name)) {
      this.IsShowLoader = false;
      this.PopUp.DisplayPopMessage('Alert', 'please upload .XLS or .XLSX extension File only.', MessageType.alert)
      return false;
    }
    reader.onload = (event) => {
      const data = reader.result;
      let workBook = XLSX.read(data, { type: 'binary' });
      let jsonData = workBook.SheetNames.reduce((data, name) => {
        const sheet = workBook.Sheets[name];
        data = XLSX.utils.sheet_to_json(sheet);
        console.log(data);
        return data;
      }, {});

      for (var i = 0; i < (jsonData as any[]).length; i++) {
        jsonData[i]['CTPushID'] = sessionStorage.getItem('CTPushID');
        jsonData[i]['isNew'] = true;
        jsonData[i]['Status'] = jsonData[i]['Status'] == 1 ? true : false;
      }
      let ExcelResult = JSON.stringify(jsonData);

      this.ojpExceptionDashboard.saveOJPExceptionEmployee(ExcelResult).subscribe((res) => {
        if (res.ResponseCode != ResponseCode.Error && res.ResponseCode != ResponseCode.InValidExcelTemplate) {
          this.IsDisplayExcelResult = true;
          this.ExcelResponse = res.Data;
        }

        else if (res.ResponseCode == ResponseCode.InValidExcelTemplate) {
          this.IsShowLoader = false;
          this.PopUp.DisplayPopMessage('Error', 'Invalid Excel Sheet Template', MessageType.error);
        }
        else {
          this.IsShowLoader = false;
          this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
        }
      }, error => {
        this.IsShowLoader = false;
        this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      });
    }
    reader.readAsBinaryString(file);
    this.IsShowLoader = false;
    this.getexceptionEmployee('', 1);
  }

  onPageChange(evt: any) {
    console.log(evt.target.textContent);
    this.getexceptionEmployee('', evt.target.textContent);
  }

}
