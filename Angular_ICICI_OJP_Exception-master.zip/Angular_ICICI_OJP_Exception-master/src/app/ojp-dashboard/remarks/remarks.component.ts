import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { OjpExceptionService } from '../../services/ojp-exception.service';
import { PopupMessageService } from '../../services/popup-message.service'

@Component({
  selector: 'app-remarks',
  templateUrl: './remarks.component.html',
  styleUrls: [ '../../global/css/modal.css', './remarks.component.css']
})
export class RemarksComponent implements OnInit {

  @Output() IsDisplayRemarks = new EventEmitter<boolean>();
  @Input() RemarkEmpID: string;

  Remarks: any;
  UserName: string;

  constructor(private ojpExceptionDashboard: OjpExceptionService,
             private popUP: PopupMessageService) { }

  ngOnInit(): void {
    this.ojpExceptionDashboard.getOJPExceptionEmpComments(this.RemarkEmpID).subscribe(res => {
      this.Remarks = res.Data;
      this.UserName = res.UserName;
    }, error=>{

    })

  }

  CloseRemarksModel(){
    this.IsDisplayRemarks.emit(false);
  }

}
