import { Component, OnInit } from '@angular/core';
import { PocService } from '../services/poc.service';
import { ResponseCode } from '../services/ojp-exception.service';
import { PopupMessageService, MessageType } from '../services/popup-message.service';
import { Router } from '@angular/router'
import { MailLog } from '../model/api.model'

@Component({
  selector: 'app-poc',
  templateUrl: './poc.component.html',
  styleUrls: ['./poc.component.css', '../global/css/modal.css']
})

export class POCComponent implements OnInit {
  IsShowLoader: boolean = false;
  IsDisplayMailBody: boolean = false;
  MailBody: string = "";
  searchMail: MailLog[] = [];
  mails: MailLog[] = [];
  SearchEmailID: string;
  constructor(private pocService: PocService,
    private PopUp: PopupMessageService,
    private router: Router) {
  }

  ngOnInit(): void {
    this.getexceptionEmployee();
  }

  getexceptionEmployee() {
    this.IsShowLoader = true;
    this.pocService.getMailLogs().subscribe((res) => {
      if (res.ResponseCode == ResponseCode.Success) {
        this.mails = <MailLog[]>res.Data;
        this.searchMail = this.mails;
      }
      this.IsShowLoader = false;
    }, error => {
      console.log(error);
      this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
    })
  }

  DisplayMailBody(mail: MailLog) {
    this.IsShowLoader = true;
    this.pocService.getMailBody(mail.RID).subscribe((res) => {
      this.IsDisplayMailBody = true;
      this.MailBody = res.replace("\\", "");
      this.IsShowLoader = false;
    }, error => {
      console.log(error);
      this.PopUp.DisplayPopMessage('Error', 'Server Error! please try again later', MessageType.error);
      this.IsShowLoader = false;
    })
  }

  CloseModel() {
    this.IsDisplayMailBody = false;
  }

  Search() {
    if (this.SearchEmailID != undefined) {
      this.mails = this.searchMail.filter(res => {
        return res.MailTo.toLocaleLowerCase().match(this.SearchEmailID.toLocaleLowerCase());
      })
    }
  }

}
