import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class EncryptionService {
secretKey: string =  "$D@mWu$0707@0r!P";
iv: string = "@1B2c3D4e5F6g7H8";

configurationsecretKey: string = "6~yH7-^xh;WcRM*";
configurationiv: string = "@1B2c3D4e5F6g7H8";
  constructor() { }

EncryptData(dataForEncryption: any): string{
 return (CryptoJS.AES.encrypt(JSON.stringify
  (dataForEncryption), this.secretKey).toString());
}
DecryptData(encryptedData: any): string{
let bytes = CryptoJS.AES.decrypt(encryptedData,this.secretKey);
return (JSON.parse(bytes.toString(CryptoJS.enc.Utf8)));
}

_encryptDataUsingAES(dataForEncryption: any): string{
  var enckey= CryptoJS.enc.Utf8.parse(this.secretKey);
  var iv = CryptoJS.enc.Utf8.parse(this.iv);
  var encstr = CryptoJS.AES.encrypt(JSON.stringify(dataForEncryption), enckey, { iv: iv });
  return encstr.toString();
};

_decryptDataUsingAES(encryptedData: any): string{
  try{
  var deckey= CryptoJS.enc.Utf8.parse(this.secretKey);
  var iv = CryptoJS.enc.Utf8.parse(this.iv);
  let bytes  = CryptoJS.AES.decrypt(encryptedData, deckey, { iv: iv });
  return (JSON.parse(bytes.toString(CryptoJS.enc.Utf8)));
  }
  catch(error){
    console.log(error);
    return "0";
  }
}


// _encryptConfigDataUsingAES(dataForEncryption: any): string{
//   var enckey= CryptoJS.enc.Utf8.parse(this.configurationsecretKey);
//   var iv = CryptoJS.enc.Utf8.parse(this.configurationiv);
//   var encstr = CryptoJS.AES.encrypt(JSON.stringify(dataForEncryption), enckey, { iv: iv });
//   return encstr.toString();
// };

_decryptConfiDataUsingAES(encryptedData: string): string{
  try{
  var deckey= '6~yH7-^xh;WcRM*';
  let bytes  = CryptoJS.AES.decrypt(encryptedData, deckey);
  return (JSON.parse(bytes.toString(CryptoJS.enc.Utf8)));



  }
  catch(error){
    console.log(error);
    return "0";
  }
}

}
