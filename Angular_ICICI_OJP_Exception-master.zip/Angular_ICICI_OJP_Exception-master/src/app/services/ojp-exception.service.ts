import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http'
import { Observable, ErrorObserver } from 'rxjs'
import { APIResponse, SaveExceptionEmployeeModel, OJPLoginResponse, OJPAPIRemarkResponse } from '../model/api.model'
import { Router } from '@angular/router'
import { environment } from 'src/environments/environment'
import { DOCUMENT } from '@angular/common';



@Injectable({
  providedIn: 'root'
})
export class OjpExceptionService {
  constructor(private http: HttpClient,
    private router: Router,
    @Inject(DOCUMENT) private document: Document) { }

  _apiPath: string = environment.SERVER_URL;
  _domainName: string = environment.Server_Domain;
  OJPValidateEmpID(EmpID: string): Observable<OJPLoginResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null)
      return (this.http.get<any>(this._apiPath + "OJPValidateEmpID?EmpID=" + EmpID));
    else
      this.logout();
  }

  OJPEmployeeExceptionLogin(empId: string, password: string): Observable<OJPLoginResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      const url: string = this._apiPath + "OJPEmployeeExceptionLogin";
      return (this.http.post<any>(url,
        {
          'EmpID': empId,
          'Password': password
        },
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        }
      ));
    }
    else
      this.logout();

  }

  getOjpExceptionEmployees(EmpID: string, PageNo: number): Observable<APIResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      const url: string = this._apiPath + "GetOJPExceptionEmployees";
      return (this.http.post<any>(url,
        {
          'EmpID': EmpID,
          'Page': PageNo
        },
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Token': sessionStorage.getItem('Token')
          })
        }
      ));
    }
    else
      this.logout();
  }

  getEmployeeBasicDetails(EmpID: string): Observable<APIResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      return (this.http.get<any>(this._apiPath + "OJPExceptionEmpBasic?EmpID=" + EmpID, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Token': sessionStorage.getItem('Token')
        })
      }))
    }
    else
      this.logout();
  }

  getOJPExceptionEmpComments(EmpID: string): Observable<OJPAPIRemarkResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      return (this.http.get<any>(this._apiPath + "GetOJPExceptionEmpComments?EmpID=" + EmpID, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Token': sessionStorage.getItem('Token')
        })
      }));
    }
    else
      this.logout();
  }

  saveOJPExceptionEmployee(employeeData: any): Observable<APIResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      const url: string = this._apiPath + "SaveOJPExceptionEmployee";
      return (this.http.post<APIResponse>(url, employeeData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Token': sessionStorage.getItem('Token')
        })
      }
      ))
    }
    else
      this.logout();
  }


  oJPExceptionEmpBasic(): Observable<APIResponse> {
    if (localStorage.getItem('H!reCr@ft.enc_empID') != null) {
      const url: string = this._apiPath + "OJPExceptionEmpBasic";
      return (this.http.post<any>(url,
        {
          'EmpID': '',
          'Page': 1
        },
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Token': sessionStorage.getItem('Token')
          })
        }));
    }
    else
      this.logout();
  }
  logout(): void {
    // sessionStorage.clear();
    // localStorage.clear();
    // this.document.location.href = this._domainName;
  }

}

export enum ResponseCode {
  Success = 100,
  Duplicate = 101,
  InvalidEmployeeID = 102,
  NoRecordFound = 103,
  Error = 104,
  InValidExcelTemplate = 105,
  UnAuthrized = 401,
  SeesionExpired = 440
}
