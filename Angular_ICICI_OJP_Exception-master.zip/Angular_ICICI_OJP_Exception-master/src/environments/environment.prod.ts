export const environment = {
  production: true,
  Server_Domain: "http://10.78.8.19/",
  SERVER_URL: "http://10.78.8.19/EGESCareers/"

};

